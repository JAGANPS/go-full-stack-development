package main

import "fmt"

func main() {

	fmt.Printf("String or number?: %s\n", 1)

}
